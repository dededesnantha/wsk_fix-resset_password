<?php	
	
	

	Route::group(['middleware' => ['injection','front_handling']], function () {
		// get
		Route::get('/', 'FrontController@index'); 
		// Route::get('link/{slug}', 'FrontController@single_product');
		// Route::get('category/all', 'FrontController@list_product');
		// Route::get('category', 'FrontController@list_product');
		// Route::get('category/{slug}', 'FrontController@list_product');
		// Route::get('blog', 'FrontController@list_blog');
		// Route::get('blog/{slug}', 'FrontController@single_blog');
		// Route::get('blog/category/{slug}', 'FrontController@list_blog');
		// Route::get('tag/{slug}', 'FrontController@list_tag');
		// Route::get('gallery.html', 'FrontController@list_gallery');
		// Route::get('gallery/{slug}', 'FrontController@list_gallery');
		// Route::get('contact.html', 'FrontController@contact');
		// Route::get('booking.html', 'FrontController@booking');
		// Route::get('review.html', 'FrontController@review');
		//post
		
		Route::post('form/pendaftaransiswa', 'FrontController@mahasiswa_send');
		Route::get('mahasiswa/{key}', 'FrontController@get_mahasiswa');
		Route::get('search', 'FrontController@search');
		Route::get('daftar/ulang', 'FrontController@get_daftar');
		Route::post('daftar/ulang', 'FrontController@login_daftar');
		Route::get('login/mahasiswa/{id}', 'FrontController@get_login');
		Route::get('logout', 'FrontController@logout');
		Route::post('form/mahasiswa/update/{id}', 'FrontController@update_daftar');
		Route::get('pendaftaran/update/berhasil', 'FrontController@success_update');



		// Route::post('contact', 'FrontController@contact_send');
		// Route::post('booking', 'FrontController@booking_send');
		// Route::post('single_booking', 'FrontController@single_send');
		// Route::post('home_booking', 'FrontController@home_send');
		// Route::post('give_review/{param}', 'FrontController@post_review');
		// Route::post('send_review', 'FrontController@send_review');

		// Route::get('contact-wa/{contact}', 'FrontController@records_wa'); 
		// Route::get('contact/{name}/{access}', 'FrontController@acces_contact'); 

		// //page
		// Route::get('/{slug}', 'FrontController@single_page');
    });