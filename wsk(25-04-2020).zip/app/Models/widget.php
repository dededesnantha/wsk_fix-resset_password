<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class widget extends Model
{
    protected $table = 'widget';
    protected $fillable = ['name'];
}
