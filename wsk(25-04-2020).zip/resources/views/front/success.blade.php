@extends('front.header_login')


@section('content')
@include('front.component.alert')
@endsection