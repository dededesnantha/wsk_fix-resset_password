@extends('front.layout')
@section('script')
@endsection
@section('content')
<div class="container">
  <div style="text-align: center;">
    <h3>Pendaftaran Siswa Baru :</h3>
  </div>
  <div class="c-12">
  @include('front.component.alert')
    <form action="{{ url('form/pendaftaransiswa') }}" method="POST" enctype="multipart/form-data" id="my-form">
      {{ csrf_field() }}
    <div class="row">
      <div class="col-25">
        <label>Nama Lengkap</label>
      </div>
      <div class="col-75">
        <input class="form-control" type="text"  required="" placeholder="Nama Lengkap" name="nama_lengkap"
        oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
        <span class="alert-warning"><i>Nama Sesuai Ijazah. Huruf Kapital Semua</i></span>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label>Nama Panggilan</label>
      </div>
      <div class="col-75">
        <input class="form-control" type="text"  required="" placeholder="Nama Panggilan" name="nama_panggilan"
        oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label>Jenis Kelamin</label>
      </div>
      <div class="col-75">
        <span>
          <input class="w3-check" type="radio" value="pria"  required="" name="jk" checked="checked"
        oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">pria
        </span>
        <span class="w3-padding">
          <input class="w3-check" type="radio" value="wanita"  required="" name="jk"
        oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">wanita
        </span>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label>NISN <span style="font-size: 12px;font-weight: 900"><i>(Opsional)</i></span></label>
      </div>
      <div class="col-75">
        <input type="number" name="nisn" placeholder="NISN">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label>NIK</label>
      </div>
      <div class="col-75">
        <input type="number" name="NIK" placeholder="NIK">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label>No.KK</label>
      </div>
      <div class="col-75">
        <input type="number"  required="" placeholder="No.kk" name="no_kk"
        oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label>No.Akta</label>
      </div>
      <div class="col-75">
        <input type="number"  required="" placeholder="No.Akta" name="no_akta"
        oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
      </div>
    </div>
   <div class="row">
      <div class="col-25">
        <label >Hobby</label>
      </div>
      <div class="col-75">
        <input type="text"  required="" placeholder="Hobby" name="hobby"
        oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label>Tempat Lahir</label>
      </div>
      <div class="col-35">
        <input type="text" required="" placeholder="Tempat Lahir" name="tempat_lahir"
        oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
      </div>
      <div class="col-15">
        <label>Tanggal Lahir</label>
      </div>
      <div class="col-25">
        <div class="sd-container">
          <p><input class="w3-input w3-padding-16 w3-border" type="date" placeholder="Date" required="" name="tanggal_lahir" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')"></p>
          <span class="open-button">
            <i class="fa fa-calendar" aria-hidden="true" style="font-size: 20px"></i>
          </span>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label>Asal Sekolah</label>
      </div>
      <div class="col-75">
        <input type="text" required="" placeholder="Asal Sekolah" name="asal_sekolah"
        oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label>Alamat Sekolah</label>
      </div>
      <div class="col-75">
        <textarea required="" name="alamat_sekolah"
        oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')" style="height:200px"></textarea>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="penyakit" style="line-height: 21px;">Berkebutuhan Khusus <span style="font-size: 12px;font-weight: 900"><i>(Opsional)</i></span></label>
      </div>
      <div class="col-75">
        <select id="penyakit" name="berkebutuhan_khusus">
          <option value="">-- Pilih --</option>
          <option value="netral">Netral</option>
          <option value="Rungu">Rungu</option>
          <option value="Grahita Ringan">Grahita Ringan</option>
          <option value="Grahita Sedang">Grahita Sedang</option>
          <option value="Daksa Ringan">Daksa Ringan</option>
          <option value="Daksa Sedang">Daksa Sedang</option>
          <option value="Laras">Laras</option>
          <option value="Wicara">Wicara</option>
          <option value="Hyperaktif">Hyperaktif</option>
          <option value="Cerdas Istimewa">Cerdas Istimewa</option>
          <option value="Bakat Istimewa">Bakat Istimewa</option>
          <option value="Kesulitan Belajar">Kesulitan Belajar</option>
          <option value="Narkoba">Narkoba</option>
          <option value="Indigo">Indigo</option>
          <option value="Down Syndrome">Down Syndrome</option>
          <option value="Autis">Autis</option>
        </select>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="agama">Agama</label>
      </div>
      <div class="col-75">
        <select id="agama" name="agama" required="" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
          <option value="">-- Pilih --</option>
          <option value="Hindu">Hindu</option>
          <option value="Islam">Islam</option>
          <option value="Kristen">Kristen</option>
          <option value="Katolik">Katolik</option>
          <option value="Buddha">Buddha</option>
          <option value="Konghucu">Kong Hu Cu</option>
          <option value="Kepercayaan kpd Tuhan YME">Kepercayaan kpd Tuhan YME</option>
          <option value="Lainnya">Lainnya</option>
        </select>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label>RT</label>
      </div>
      <div class="col-75">
        <input type="text" name="RT" placeholder="RT">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label >RW</label>
      </div>
      <div class="col-75">
        <input type="text" name="RW" placeholder="RW">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="tempat">Tempat Tinggal</label>
      </div>
      <div class="col-75">
        <select id="tempat" name="tempat_tinggal" required="" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
          <option value="Bersama Orang Tua">Bersama Orang Tua</option>
          <option value="Wali">Wali</option>
          <option value="Kost">Kost</option>
          <option value="Asrama">Asrama</option>
          <option value="Panti Asuhan">Panti Asuhan</option>
          <option value="Pesantren">Pesantren</option>
          <option value="Lainnya">Lainnya</option>
        </select>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="tempat">Mode Transportasi</label>
      </div>
      <div class="col-75">
        <select id="tempat" name="transportasi" required="" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
          <option value="Sepeda Motor">Sepeda Motor</option>
          <option value="Sepeda">Sepeda</option>
          <option value="Kuda">Kuda</option>
          <option value="Perahu Penyebrangan">Perahu Penyebrangan</option>
          <option value="Andong">Andong</option>
          <option value="Ojek">Ojek</option>
          <option value="Kereta Api">Kereta Api</option>
          <option value="Mobil/Bus">Mobil/Bus</option>
          <option value="Angkutan Umum">Angkutan Umum</option>
          <option value="Jalan Kaki">Jalan Kaki</option>
        </select>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label>Kewarganegaraan</label>
      </div>
      <div class="col-75">
        <input type="text" name="kewarganegaraan" value="indonesia" readonly="readonly" style="background-color: #f2f2f2" />
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="fname">Suku Bangsa</label>
      </div>
      <div class="col-75">
        <input type="text" name="suku_bangsa" placeholder="Suku Bangsa" required="" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
        <span class="alert-warning"><i>Contoh : jawa, bali, aceh, dll</i></span>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="anak">Anak Ke-</label>
      </div>
      <div class="col-75">
        <select id="anak" name="anak_ke" required="" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
          <option value="0">-- Pilih --</option>
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
          <option value="6">6</option>
          <option value="7">7</option>
          <option value="8">8</option>
          <option value="9">9</option>
          <option value="10">10</option>
          <option value="11">11</option>
          <option value="12">12</option>
          <option value="13">13</option>
          <option value="14">14</option>
          <option value="15">15</option>
        </select>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="status">Status Siswa</label>
      </div>
      <div class="col-75">
        <select id="status" name="status_siswa">
          <option value="">-- Pilih --</option>
          <option value="Anak Yatim">Anak Yatim</option>
          <option value="Piatu">Piatu</option>
          <option value="Yatim Piatu">Yatim Piatu</option>
        </select>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="Beasiswa">Pernah Mendapatkan Beasiswa</label>
      </div>
      <div class="col-75">
        <select id="Beasiswa" name="beasiswa">
          <option value="">-- Pilih --</option>
          <option value="KIP">KIP</option>
          <option value="KPS">KPS</option>
          <option value="KKS">KKS</option>
          <option value="PKH">PKH</option>
          <option value="YAITM PIATU">YAITM PIATU</option>
          <option value="YATIM">YATIM</option>
          <option value="PIATU">PIATU</option>
        </select>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="jumlah">Jumlah Saudara</label>
      </div>
      <div class="col-75">
        <select id="jumlah" name="saudara" required="" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
          <option value="0">-- Pilih --</option>
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
          <option value="6">6</option>
          <option value="7">7</option>
          <option value="8">8</option>
          <option value="9">9</option>
          <option value="10">10</option>
          <option value="11">11</option>
          <option value="12">12</option>
          <option value="13">13</option>
          <option value="14">14</option>
          <option value="15">15</option>
        </select>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label>Alamat Rumah</label>
      </div>
      <div class="col-75">
        <textarea name="alamat_rumah" required="" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')" style="height:200px"></textarea>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label>Provinsi</label>
      </div>
      <div class="col-75">
        <input type="text" name="provinsi" placeholder="provinsi" required="" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label>Kabupaten</label>
      </div>
      <div class="col-75">
        <input type="text" name="kabupaten" placeholder="kabupaten" required="" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
      </div>
    </div>
     <div class="row">
      <div class="col-25">
        <label>Kecamatan</label>
      </div>
      <div class="col-75">
        <input type="text" name="kecamatan" placeholder="Kecamatan" required="" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label>Kode Pos</label>
      </div>
      <div class="col-75">
        <input type="number" name="kode_pos" placeholder="Kode Pos" required="" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label >Alamat Pos</label>
      </div>
      <div class="col-75">
        <textarea name="alamat_pos" style="height:200px"></textarea>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label>Lintang <span style="font-size: 12px;font-weight: 900"><i>(Opsional)</i></span></label>
      </div>
      <div class="col-75">
        <input type="number" name="lintang" placeholder="Lintang">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label>Bujur <span style="font-size: 12px;font-weight: 900"><i>(Opsional)</i></span></label>
      </div>
      <div class="col-75">
        <input type="number" name="bujur" placeholder="Bujur">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label>Nomor Hp</label>
      </div>
      <div class="col-75">
        <input type="number" name="hpsiswa" placeholder="Nomor Hp" required="" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
        <span class="alert-warning"><i>Contoh: 085*****</i></span>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label>Nomor Tel.Rumah</label>
      </div>
      <div class="col-75">
        <input type="number" name="tlp_rumah" placeholder="Nomor Tel.Rumah">
        <span class="alert-warning"><i>Contoh: 027*****</i></span>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label>Email</label>
      </div>
      <div class="col-75">
        <input type="email" name="email" placeholder="Email" required="" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label>Golongan Darah</label>
      </div>
      <div class="col-75">
        <span>
          <input type="radio" name="golongan_darah" value="A" class="w3-check"> A
        </span>
        <span class="w3-padding">
          <input type="radio" name="golongan_darah" value="B" class="w3-check"> B
        </span>
        <span class="w3-padding">
          <input type="radio" name="golongan_darah" value="AB" class="w3-check"> AB
        </span>
        <span class="w3-padding">
          <input type="radio" name="golongan_darah" value="O" class="w3-check"> O
        </span>
        <span class="w3-padding">
          <input type="radio" name="golongan_darah" value="" class="w3-check"> Tidak Ada
        </span>
      </div>
    </div>
     <div class="row">
      <div class="col-25">
        <label>Tinggi Badan <span style="font-size: 12px;font-weight: 900"><i>(Cm)</i></span></label>
      </div>
      <div class="col-75">
        <input type="number" name="tinggi_badan"placeholder="Tinggi badan" required="" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
        <span class="alert-warning"><i>Contoh: 160, 150, dll</i></span>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label>Berat Badan <span style="font-size: 12px;font-weight: 900"><i>(Kg)</i></span></label>
      </div>
      <div class="col-75">
        <input type="number" name="berat_badan" placeholder="Berat Badan" required="" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
        <span class="alert-warning"><i>Contoh: 70, 40, dll</i></span>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label>Lingkaran Kepala </label>
      </div>
      <div class="col-75">
        <input type="number" name="lingkaran_kepala" placeholder="Lingkar Kepala">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="riwayat">Riwayat Penyakit</label>
      </div>
      <div class="col-75">
        <textarea id="riwayat" name="riwayat_penyakit" placeholder="Riwayat Penyakit" style="height:200px"></textarea>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="keterangan">Keterangan Lain</label>
      </div>
      <div class="col-75">
        <textarea id="keterangan" name="keterangan" placeholder="Keterangan Lain" style="height:200px"></textarea>
      </div>
    </div>

    <div style="text-align: center; margin-top: 50px">
      <h3 style="padding-bottom: 0; margin-bottom: 0;">Data Nilai Ujian Nasional : </h3>
      <span class="alert-warning" style="padding: 0; margin: 0;"><i>(Wajib Diisi)</i></span>
    </div>
    <div class="row">
      <div class="col-25">
        <label>Bahasa Indonesia </label>
      </div>
      <div class="col-75">
        <input type="number" name="bahasa_indonesia" placeholder="Nilai Bahasa Indonesia" required="" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label>Bahasa Inggris </label>
      </div>
      <div class="col-75">
        <input type="number" name="bahasa_inggris" placeholder="Nilai Bahasa Inggris" required="" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label>Matematika</label>
      </div>
      <div class="col-75">
        <input type="number" name="matematika" placeholder="Nilai Matematika" required="" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label>Ilmu Pengetahuan Alam</label>
      </div>
      <div class="col-75">
        <input type="number" name="ipa" placeholder="Nilai Ilmu Pengetahuan Alam" required="" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
      </div>
    </div>
    <span class="alert-warning" style="padding: 0; margin: 0;"><i>* Nilai Ujian Nasional, Sementara Diisi Anggka 0 Semuanya (Keempat Kolom Studi Diataas)*</i></span>

    <div style="text-align: center; margin-top: 50px">
      <h3 style="padding-bottom: 0; margin-bottom: 0;">Data Prestasi Siswa : </h3>
      <span class="alert-warning" style="padding: 0; margin: 0;"><i>(Wajib Diisi)</i></span>
    </div>
    <div class="row">
      <div class="col-25">
        <label>Nilai Prestasi</label>
      </div>
      <div class="col-75">
        <input type="number" name="nilai_prestasi" placeholder="Nilai Prestasi" required="" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
         <span class="alert-warning" style="padding: 0; margin: 0;"><i>* Nilai Prestasi Diisi 0 Jika Tidak Punya Prestasi Akademis/Non.Akademis. Jika Mempunyai Prestasi 
    Akademis / Non Akademis Saat di SMP Isikan Nilai 5 = Tingkat Sekolah, 6 = Kecamatan, 7 = Kabupaten, 8 = Provinsi, 9 = Nasional, 10 = Internasional*</i></span>
      </div>
    </div>

     <div style="text-align: center; margin-top: 50px">
      <h3 style="padding-bottom: 0; margin-bottom: 0;">Data Program Keahlian Yang Ada : </h3>
    </div>
    <div class="row">
      <div class="col-25">
        <label>Program Keahlian</label>
      </div>
      <div class="col-75">
        <span>
          <input type="radio" name="jurusan" value="perhotelan" class="w3-check" required="" checked="checked" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')"> Perhotelan
        </span>
        <span class="w3-padding">
          <input type="radio" name="jurusan" value="tata boga" class="w3-check" required="" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')"> Tata Boga
        </span>
      </div>
    </div>

    <div style="text-align: center; margin-top: 50px">
      <h3 style="padding-bottom: 0; margin-bottom: 0;">Data Orang Tua/Wali Siswa : </h3>
    </div>
    <div class="row">
      <div class="col-25">
        <label>Nama Ayah</label>
      </div>
      <div class="col-75">
        <input type="text" name="nama_ayah" placeholder="Nama Ayah" required="" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label>NIK Ayah</label>
      </div>
      <div class="col-25">
        <input type="text" required="" placeholder="NIK Ayah" name="nik_ayah"
        oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
      </div>
      <div class="col-25">
        <label>Tanggal Lahir Ayah</label>
      </div>
      <div class="col-25">
        <div class="sd-container">
          <p><input class="w3-input w3-padding-16 w3-border" type="date" placeholder="Date" required="" name="lahir_ayah" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')"></p>
          <span class="open-button">
            <i class="fa fa-calendar" aria-hidden="true" style="font-size: 20px"></i>
          </span>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="pendidikan">Pendidikan Ayah</label>
      </div>
      <div class="col-75">
        <select id="pendidikan" name="pendidikan_ayah" required="" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
          <option value="">-- Pilih --</option>
          <option value="Tidak Sekolah">Tidak Sekolah</option>
          <option value="Putus SD">Putus SD</option>
          <option value="TK">TK</option>
          <option value="SD">SD</option>
          <option value="SMP">SMP</option>
          <option value="SMA">SMA</option>
          <option value="D1">D1</option>
          <option value="D2">D2</option>
          <option value="D3">D3</option>
          <option value="S1">S1</option>
          <option value="S2">S2</option>
          <option value="S3">S3</option>
          <option value="Paket A">Paket A</option>
          <option value="Paket B">Paket B</option>
          <option value="Paket C">Paket C</option>
          <option value="Lainnya">Lainnya</option>
        </select>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="pekerjaan">Pekerjaan Ayah</label>
      </div>
      <div class="col-75">
        <select id="pekerjaan" name="pekerjaan_ayah" required="" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
          <option value="">-- Pilih --</option>
          <option value="Buruh">Buruh</option>
          <option value="PNS">PNS</option>
          <option value="TNI">TNI</option>
          <option value="Polri">Polri</option>
          <option value="Karyawan Swasta">Karyawan Swasta</option>
          <option value="Petani">Petani</option>
          <option value="Nelayan">Nelayan</option>
          <option value="Pedagang Besar">Pedagang Besar</option>
          <option value="Pedagang Kecil">Pedagang Kecil</option>
          <option value="Pensiunan">Pensiunan</option>
          <option value="Peternak">Peternak</option>
          <option value="Wiraswasta">Wiraswasta</option>
          <option value="Tenaga Kerja Indonesia">Tenaga Kerja Indonesia</option>
          <option value="Wiraswasta">Wiraswasta</option>
          <option value="Wirausaha">Wirausaha</option>
          <option value="Sudah Meninggal">Sudah Meninggal</option>
         <option value="Dan Lain-Lain">Dan Lain - Lain</option>
        </select>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="penghasil_ayah">Penghasilan Ayah</label>
      </div>
      <div class="col-75">
        <select id="penghasil_ayah" name="penghasilan_ayah">
          <option value="Kurang Dari Rp.500.000">Kurang Dari Rp.500.000</option>
          <option value="Rp.500.000 - Rp.1.000.000">Rp.500.000 - Rp.1.000.000</option>
          <option value="Rp.1.000.000 - Rp.2.000.000">Rp.1.000.000 - Rp.2.000.000</option>
          <option value="Rp.2.000.000 - Rp.5.000.000">Rp.2.000.000 - Rp.5.000.000</option>
          <option value="Rp.5.000.000 - Rp.20.000.000">Rp.5.000.000 - Rp.20.000.000</option>
          <option value="Lebih dari Rp.20.000.000">Lebih dari Rp.20.000.000</option>
          <option value="Tidak berpenghasilan">Tidak Berpenghasilan</option>
        </select>
      </div>
  </div>
    <div class="row">
      <div class="col-25">
        <label>Nomor Hp Ayah</label>
      </div>
      <div class="col-75">
        <input type="number" name="hpayah" placeholder="Nomor Hp Ayah">
        <span class="alert-warning"><i>Contoh: 085*****</i></span>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="penyakit_ayah" style="line-height: 21px;">Berkebutuhan Khusus <span style="font-size: 12px;font-weight: 900"><i>(Opsional)</i></span></label>
      </div>
      <div class="col-75">
        <select id="penyakit_ayah" name="penyakit_ayah">
          <option value="">-- Pilih --</option>
          <option value="netral">Netral</option>
          <option value="Rungu">Rungu</option>
          <option value="Grahita Ringan">Grahita Ringan</option>
          <option value="Grahita Sedang">Grahita Sedang</option>
          <option value="Daksa Ringan">Daksa Ringan</option>
          <option value="Daksa Sedang">Daksa Sedang</option>
          <option value="Laras">Laras</option>
          <option value="Wicara">Wicara</option>
          <option value="Hyperaktif">Hyperaktif</option>
          <option value="Cerdas Istimewa">Cerdas Istimewa</option>
          <option value="Bakat Istimewa">Bakat Istimewa</option>
          <option value="Kesulitan Belajar">Kesulitan Belajar</option>
          <option value="Narkoba">Narkoba</option>
          <option value="Indigo">Indigo</option>
          <option value="Down Syndrome">Down Syndrome</option>
          <option value="Autis">Autis</option>
        </select>
      </div>
    </div>
     <div class="row">
      <div class="col-25">
        <label>Nama Ibu</label>
      </div>
      <div class="col-75">
        <input type="text" name="nama_ibu" placeholder="Nama Ibu" required="" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label>NIK Ibu</label>
      </div>
      <div class="col-25">
        <input type="text" required="" placeholder="NIK Ibu" name="nik_ibu"
        oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
      </div>
      <div class="col-25">
        <label>Tanggal Lahir Ibu</label>
      </div>
      <div class="col-25">
        <div class="sd-container">
          <p><input class="w3-input w3-padding-16 w3-border" type="date" placeholder="Date" required="" name="lahir_ibu" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')"></p>
          <span class="open-button">
            <i class="fa fa-calendar" aria-hidden="true" style="font-size: 20px"></i>
          </span>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="pendidikan_ibu">Pendidikan Ibu</label>
      </div>
      <div class="col-75">
        <select id="pendidikan_ibu" name="pendidikan_ibu" required="" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
          <option value="">-- Pilih --</option>
          <option value="Tidak Sekolah">Tidak Sekolah</option>
          <option value="Putus SD">Putus SD</option>
          <option value="TK">TK</option>
          <option value="SD">SD</option>
          <option value="SMP">SMP</option>
          <option value="SMA">SMA</option>
          <option value="D1">D1</option>
          <option value="D2">D2</option>
          <option value="D3">D3</option>
          <option value="S1">S1</option>
          <option value="S2">S2</option>
          <option value="S3">S3</option>
          <option value="Paket A">Paket A</option>
          <option value="Paket B">Paket B</option>
          <option value="Paket C">Paket C</option>
          <option value="Lainnya">Lainnya</option>
        </select>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="pekerjaan_ibu">Pekerjaan Ibu</label>
      </div>
      <div class="col-75">
        <select id="pekerjaan_ibu" name="pekerjaan_ibu" required="" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')">
          <option value="">-- Pilih --</option>
          <option value="Buruh">Buruh</option>
          <option value="PNS">PNS</option>
          <option value="TNI">TNI</option>
          <option value="Polri">Polri</option>
          <option value="Karyawan Swasta">Karyawan Swasta</option>
          <option value="Petani">Petani</option>
          <option value="Nelayan">Nelayan</option>
          <option value="Pedagang Besar">Pedagang Besar</option>
          <option value="Pedagang Kecil">Pedagang Kecil</option>
          <option value="Pensiunan">Pensiunan</option>
          <option value="Peternak">Peternak</option>
          <option value="Wiraswasta">Wiraswasta</option>
          <option value="Tenaga Kerja Indonesia">Tenaga Kerja Indonesia</option>
          <option value="Wiraswasta">Wiraswasta</option>
          <option value="Wirausaha">Wirausaha</option>
          <option value="Sudah Meninggal">Sudah Meninggal</option>
         <option value="Dan Lain-Lain">Dan Lain - Lain</option>
        </select>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="penghasil_ibu">Penghasilan Ibu</label>
      </div>
      <div class="col-75">
        <select id="penghasil_ibu" name="penghasilan_ibu">
          <option value="Kurang Dari Rp.500.000">Kurang Dari Rp.500.000</option>
          <option value="Rp.500.000 - Rp.1.000.000">Rp.500.000 - Rp.1.000.000</option>
          <option value="Rp.1.000.000 - Rp.2.000.000">Rp.1.000.000 - Rp.2.000.000</option>
          <option value="Rp.2.000.000 - Rp.5.000.000">Rp.2.000.000 - Rp.5.000.000</option>
          <option value="Rp.5.000.000 - Rp.20.000.000">Rp.5.000.000 - Rp.20.000.000</option>
          <option value="Lebih dari Rp.20.000.000">Lebih dari Rp.20.000.000</option>
          <option value="Tidak berpenghasilan">Tidak Berpenghasilan</option>
        </select>
      </div>
  </div>
    <div class="row">
      <div class="col-25">
        <label>Nomor Hp Ibu</label>
      </div>
      <div class="col-75">
        <input type="number" name="hpibu" placeholder="Nomor Hp Ibu">
        <span class="alert-warning"><i>Contoh: 085*****</i></span>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="penyakit_ibu" style="line-height: 21px;">Berkebutuhan Khusus <span style="font-size: 12px;font-weight: 900"><i>(Opsional)</i></span></label>
      </div>
      <div class="col-75">
        <select id="penyakit_ibu" name="penyakit_ibu">
          <option value="">-- Pilih --</option>
          <option value="netral">Netral</option>
          <option value="Rungu">Rungu</option>
          <option value="Grahita Ringan">Grahita Ringan</option>
          <option value="Grahita Sedang">Grahita Sedang</option>
          <option value="Daksa Ringan">Daksa Ringan</option>
          <option value="Daksa Sedang">Daksa Sedang</option>
          <option value="Laras">Laras</option>
          <option value="Wicara">Wicara</option>
          <option value="Hyperaktif">Hyperaktif</option>
          <option value="Cerdas Istimewa">Cerdas Istimewa</option>
          <option value="Bakat Istimewa">Bakat Istimewa</option>
          <option value="Kesulitan Belajar">Kesulitan Belajar</option>
          <option value="Narkoba">Narkoba</option>
          <option value="Indigo">Indigo</option>
          <option value="Down Syndrome">Down Syndrome</option>
          <option value="Autis">Autis</option>
        </select>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="alamat">Alamat Orang Tua</label>
      </div>
      <div class="col-75">
        <textarea id="alamat" name="alamat_orangtua" placeholder="Alamat Orang Tua" style="height:200px" required="" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')"></textarea>
      </div>
    </div>
     <div class="row">
      <div class="col-25">
        <label>Nama Wali</label>
      </div>
      <div class="col-75">
        <input type="text" name="nama_wali" placeholder="Nama Wali">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="pendidikan_wali">Pendidikan Wali</label>
      </div>
      <div class="col-75">
        <select id="pendidikan_wali" name="pendidikan_wali">
          <option value="">-- Pilih --</option>
          <option value="Tidak Sekolah">Tidak Sekolah</option>
          <option value="Putus SD">Putus SD</option>
          <option value="TK">TK</option>
          <option value="SD">SD</option>
          <option value="SMP">SMP</option>
          <option value="SMA">SMA</option>
          <option value="D1">D1</option>
          <option value="D2">D2</option>
          <option value="D3">D3</option>
          <option value="S1">S1</option>
          <option value="S2">S2</option>
          <option value="S3">S3</option>
          <option value="Paket A">Paket A</option>
          <option value="Paket B">Paket B</option>
          <option value="Paket C">Paket C</option>
          <option value="Lainnya">Lainnya</option>
        </select>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="pekerjaan_wali">Pekerjaan Wali</label>
      </div>
      <div class="col-75">
        <select id="pekerjaan_wali" name="pekerjaan_wali">
          <option value="">-- Pilih --</option>
          <option value="Buruh">Buruh</option>
          <option value="PNS">PNS</option>
          <option value="TNI">TNI</option>
          <option value="Polri">Polri</option>
          <option value="Karyawan Swasta">Karyawan Swasta</option>
          <option value="Petani">Petani</option>
          <option value="Nelayan">Nelayan</option>
          <option value="Pedagang Besar">Pedagang Besar</option>
          <option value="Pedagang Kecil">Pedagang Kecil</option>
          <option value="Pensiunan">Pensiunan</option>
          <option value="Peternak">Peternak</option>
          <option value="Wiraswasta">Wiraswasta</option>
          <option value="Tenaga Kerja Indonesia">Tenaga Kerja Indonesia</option>
          <option value="Wiraswasta">Wiraswasta</option>
          <option value="Wirausaha">Wirausaha</option>
          <option value="Sudah Meninggal">Sudah Meninggal</option>
         <option value="Dan Lain-Lain">Dan Lain - Lain</option>
        </select>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="penghasil_Wali">Penghasilan Wali</label>
      </div>
      <div class="col-75">
        <select id="penghasil_Wali" name="penghasilan_wali">
          <option value="">-- Pilih --</option>
          <option value="Kurang Dari Rp.500.000">Kurang Dari Rp.500.000</option>
          <option value="Rp.500.000 - Rp.1.000.000">Rp.500.000 - Rp.1.000.000</option>
          <option value="Rp.1.000.000 - Rp.2.000.000">Rp.1.000.000 - Rp.2.000.000</option>
          <option value="Rp.2.000.000 - Rp.5.000.000">Rp.2.000.000 - Rp.5.000.000</option>
          <option value="Rp.5.000.000 - Rp.20.000.000">Rp.5.000.000 - Rp.20.000.000</option>
          <option value="Lebih dari Rp.2.000.000">Lebih dari Rp.2.000.000</option>
          <option value="Tidak berpenghasilan">Tidak Berpenghasilan</option>
        </select>
      </div>
  </div>
    <div class="row">
      <div class="col-25">
        <label>Nomor Hp wali</label>
      </div>
      <div class="col-75">
        <input type="number" name="hpwali" placeholder="Nomor Hp Wali">
        <span class="alert-warning"><i>Contoh: 085*****</i></span>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="alamat_wali">Alamat Wali</label>
      </div>
      <div class="col-75">
        <textarea id="alamat_wali" name="alamat_wali" placeholder="Alamat Wali" style="height:200px"></textarea>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label>Status Asuh</label>
      </div>
      <div class="col-75">
        <span>
          <input type="radio" name="status_asuh" value="Orang Tua" class="w3-check" checked="checked" required="" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')"> Orang Tua
        </span>
        <span class="w3-padding">
          <input type="radio" name="status_asuh" value="Wali" class="w3-check" required="" oninvalid="this.setCustomValidity('Wajib Diisi')"
        oninput="setCustomValidity('')"> Wali
        </span>
      </div>
    </div>
    <div class="row">
      <div class="c-12" style="margin-bottom: 10px">
        <div style="float: right;">
            <label for="mathgroup">{{ app('mathcaptcha')->label() }}</label>
            <div style="display: block;">
             {!! app('mathcaptcha')->input(['class' => 'form-control', 'id' => 'mathgroup']) !!}
             @if ($errors->has('mathcaptcha'))
             <span class="help-block">
              <span class="alert-error">{{ $errors->first('mathcaptcha') }}</span>
            </span>
            @endif
          </div>
        </div>
      </div>
      <div class="c-12">
      <input type="submit" value="Submit">
      </div>
      </div>
    </div>
    </form>
  </div>
</div>

@endsection