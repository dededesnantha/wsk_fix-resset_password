@extends('front.amp.layout')
@section('content')
<section class="block-section">
    <div class="p-0-15 text-center">
      <h1 class="text-center">Review </h1>
      <a href="{{ url('review.html') }}" title="booking" class="btn">Click To See Review </a>
    </div>
</section>

@endsection     