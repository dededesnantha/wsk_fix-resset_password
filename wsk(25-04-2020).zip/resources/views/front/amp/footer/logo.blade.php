	
		<a href="{{url('/')}}" title="{{$main['profile_website']->judul}}"><amp-img src="{{url('image').'/'.$main['profile_website']->logo}}" alt="logo" width="120px" height="120px"></amp-img></a>
		<br>		