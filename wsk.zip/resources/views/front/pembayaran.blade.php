@extends('front.layout_pembayaran')
@section('content')
<div class="container">
	<div class="c-12">
		<div class="" style="text-align: center;">
			<table>
				<tr>
					<td>No.Rekening</td>
					<td>:</td>
					<td>4660-01-009973-53-5</td>
				</tr>
				<tr>
					<td>Unit Bank</td>
					<td>:</td>
					<td>4460 UNIT BATUBULAN UBUD</td>
				</tr>
				<tr>
					<td>NAMA </td>
					<td>:</td>
					<td>SMK WERDHI SILA KUMARA</td>
			</table>
		</div>
	</div>
</div>

<div class="container-fluit">
	<div class="c-12">
		<div style="margin: 0 auto; text-align: center;">
			<img src="{{url('image/sm')}}/form-1.JPEG" alt="">		
		</div>
	</div>
</div>
@endsection