@if($row->judul != '')
		<h3 class="font-secondary color-white" >{{$row->judul}}</h3>
@endif
		<div>
			
		<?= $main['profile_website']->map; ?>		
		</div>
		