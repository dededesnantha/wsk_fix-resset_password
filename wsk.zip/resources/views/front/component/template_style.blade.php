<style>nav ul#menu{background-color: #38AA4B !important;}
.w3-code{width:auto;background-color:#fff;padding:8px 12px;border-left:4px solid [link];word-wrap:break-word}
  .pagination > li > a, .pagination > li > span {     color:  #38AA4B ; }
  .pagination > .active > a, .pagination > .active > span, .pagination > .active > a:hover, .pagination > .active > span:hover, .pagination > .active > a:focus, .pagination > .active > span:focus {     background-color:  #38AA4B ; }
  a{color:#56B865}
  a.link{color:#000}
 li.nav a {color: #fff;}
 li.nav:hover a {background: #38AA4B;}
 li.nav:hover ul.nav a {background: #38AA4B;color: #ffffff;}
 li.nav:hover ul.nav a:hover {background: #38AA4B;color: #ffffff;}
 /*serach*/ #search {background: #fff;color: #63717f;}
 /*accordion*/ .tab {color: #000;}
 label {background: #38AA4B;}
 .tab-content {background: #E6E6E6;color: #000}
 /*main*/ /*background*/ .w3-white,.w3-hover-white:hover{color:#272822 !important;background-color:#fff!important}
 .w3-grey,.w3-hover-grey:hover,.w3-gray,.w3-hover-gray:hover{color:#fff!important;background-color: #38AA4B !important}
 .w3-light-grey,.w3-hover-light-grey:hover,.w3-light-gray,.w3-hover-light-gray:hover{color:#fff!important;background-color: #38AA4B !important}
 .w3-dark-grey,.w3-hover-dark-grey:hover,.w3-dark-gray,.w3-hover-dark-gray:hover{color:#fff!important;background-color:#38AA4B !important}
 .w3-black,.w3-hover-black:hover{color:#fff!important;background-color: #38AA4B !important;}
 /*text*/ .w3-text-white,.w3-hover-text-white:hover{color: #ffffff !important}
 .w3-text-black,.w3-hover-text-black:hover{color:#000!important}
 .w3-text-grey,.w3-hover-text-grey:hover,.w3-text-gray,.w3-hover-text-gray:hover{color:#757575!important}
  .slider div {   background-color:  #38AA4B ;   border-bottom: 1.5px solid #38AA4B; }
/*sub footer*/
.w3-dark-grey.w3-padding-small.w3-card-2{
	background-color: #38AA4B !important;
	color: #ffffff !important;
}
.w3-light-grey.w3-center.w3-padding-small{
	background-color: #38AA4B !important;
	color: #ffffff !important;
}</style>