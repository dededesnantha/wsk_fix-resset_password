@if($row->judul != '')
		<h3>{{$row->judul}}</h3>
@endif
		<div class="color-white text-left"><?= $main['profile_website']->deskripsi ?></div>
		